#!/bin/bash
echo "→ Installation du mode FULL (Offensif + Défensif)..."
"$(dirname "$0")/offensive.sh"
"$(dirname "$0")/defensive.sh"
echo "✅ Mode FULL terminé."