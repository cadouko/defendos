#!/bin/bash
echo "→ Installation des outils OFFENSIFS (Pentest / Red Team)..."

pacman -S --noconfirm --needed blackarch-recon blackarch-scanner blackarch-exploitation \
    blackarch-webapp blackarch-fuzzer blackarch-proxy blackarch-spoof blackarch-wireless \
    blackarch-cracker blackarch-sniffer

pacman -S --noconfirm --needed \
    metasploit sqlmap nuclei ffuf feroxbuster dirsearch \
    nmap masscan rustscan gobuster burpsuite community-edition \
    thc-hydra john hashcat responder impacket

echo "✅ Module Offensif installé."