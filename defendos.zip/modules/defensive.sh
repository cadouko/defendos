#!/bin/bash
echo "→ Installation des outils DÉFENSIFS (Blue Team / SIEM light)..."

pacman -S --noconfirm --needed \
    suricata zeek ossec-hids fail2ban lynis clamav rkhunter auditd \
    scap-security-guide openvas wireshark-qt tcpdump tshark

# Installation de yay si absent
if ! command -v yay &> /dev/null; then
    echo "Installation de yay (AUR helper)..."
    git clone https://aur.archlinux.org/yay.git /tmp/yay
    cd /tmp/yay && makepkg -si --noconfirm
    cd - && rm -rf /tmp/yay
fi

echo "Installation de Wazuh Agent..."
yay -S --noconfirm wazuh-agent || echo "⚠️ Wazuh via AUR échoué (tu peux l'installer manuellement plus tard)."

echo "✅ Module Défensif installé."