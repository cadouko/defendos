#!/bin/bash
echo "=========================================="
echo "     Bienvenue dans DefendOS Live !"
echo "=========================================="
echo "Outils disponibles : nmap, metasploit, nuclei, suricata, lynis..."
echo "Pour installer sur disque : ./install.sh"