DefendOS/
├── README.md
├── install.sh
├── modules/
│   ├── offensive.sh
│   ├── defensive.sh
│   └── full.sh
├── config/
│   ├── hardening.md
│   ├── suricata.yaml.example
│   └── wazuh-agent.conf.example
├── docs/
│   ├── tools-offensif.md
│   ├── tools-defensif.md
│   └── roadmap.md
└── scripts/
    └── post-install-hardening.sh


# DefendOS

Distribution cyber modulaire basée sur **Arch Linux + BlackArch**.

**Objectifs** :
- Mix offensif (pentest, red team) + défensif (blue team, monitoring, hardening)
- Léger et reproductible via scripts
- Open source et communautaire

## Installation rapide

```bash
git clone https://github.com/tonusername/DefendOS.git
cd DefendOS
chmod +x modules/*.sh
sudo ./install.sh full

chmod +x scripts/hardening.sh


## Modules disponibles

Offensif : Nmap, Metasploit, Burp Suite (community), SQLMap, Nuclei, ffuf, etc.
Défensif : Suricata, Zeek, Lynis, Fail2Ban, ClamAV, Wazuh agent, OpenVAS
Full : Les deux


# DefendOS

**Distribution cyber modulaire basée sur Arch Linux + BlackArch**

Mix équilibré **Offensif (Red Team / Pentest)** + **Défensif (Blue Team / SIEM light)**.

## Fonctionnalités

- Installation scriptable et modulaire (`install.sh`)
- Outils offensifs : Metasploit, Nuclei, SQLMap, ffuf, Burp Suite, etc.
- Outils défensifs : Suricata, Zeek, Wazuh Agent, Lynis, Fail2Ban, OpenVAS, Auditd
- Hardening avancé intégré (SSH, sysctl, AppArmor, auditd)
- Futur : ISO live personnalisée avec `archiso`

## Installation rapide (sur une Arch propre ou VM)

```bash
git clone https://github.com/tonusername/DefendOS.git
cd DefendOS
sudo ./install.sh
sudo ./scripts/hardening.sh