#!/bin/bash
# DefendOS Installer v0.3 - Arch + BlackArch

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}=== DefendOS Installer v0.3 ===${NC}"
echo -e "Arch Linux + BlackArch | Mix Offensif + Défensif\n"

if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}Ce script doit être exécuté avec sudo ou en root.${NC}"
    exit 1
fi

# Mise à jour système + BlackArch
pacman -Syu --noconfirm

if ! pacman -Q blackarch-keyring &> /dev/null; then
    echo -e "${YELLOW}Installation du dépôt BlackArch...${NC}"
    curl -O https://blackarch.org/strap.sh
    # Note : vérifie toujours le checksum sur https://blackarch.org/ si possible
    chmod +x strap.sh
    ./strap.sh
    rm strap.sh
fi

pacman -Syu --noconfirm

# Paquets de base
pacman -S --noconfirm --needed base-devel git curl wget zsh tmux neovim htop \
    ufw firewalld apparmor apparmor-profiles wireshark-qt tcpdump tshark nmap

echo -e "\n${GREEN}Choisis le module à installer :${NC}"
echo "1) Full (Offensif + Défensif)  ← Recommandé"
echo "2) Offensif seulement (Pentest / Red Team)"
echo "3) Défensif seulement (Blue Team / SIEM light)"
echo "4) Quitter"
read -p "Ton choix [1-4] : " choice

case $choice in
    1)
        ./modules/full.sh
        ;;
    2)
        ./modules/offensive.sh
        ;;
    3)
        ./modules/defensive.sh
        ;;
    4)
        echo "Installation annulée."
        exit 0
        ;;
    *)
        echo -e "${RED}Choix invalide → Installation Full par défaut.${NC}"
        ./modules/full.sh
        ;;
esac

# Post-install hardening de base
echo -e "\n${YELLOW}Configuration hardening basique...${NC}"
systemctl enable --now apparmor
aa-enforce /etc/apparmor.d/* 2>/dev/null || true

ufw default deny incoming
ufw default allow outgoing
ufw --force enable
systemctl enable --now ufw

echo -e "${GREEN}=== Installation DefendOS terminée avec succès ! ===${NC}"
echo "Tu peux maintenant lancer : nmap, metasploit, nuclei, suricata, lynis..."
echo "Prochaine étape : sudo ./scripts/hardening.sh"