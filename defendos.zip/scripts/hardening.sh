#!/bin/bash
# DefendOS - Hardening Avancé

set -e
echo "=== DefendOS Hardening Avancé ==="

# SSH Hardening
echo "Configuration SSH sécurisée..."
cat <<EOF | sudo tee /etc/ssh/sshd_config.d/99-defendos-hardening.conf > /dev/null
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
PermitEmptyPasswords no
MaxAuthTries 3
ClientAliveInterval 300
ClientAliveCountMax 0
AllowTcpForwarding no
X11Forwarding no
PermitTunnel no
EOF

sudo systemctl restart sshd

# sysctl Hardening
echo "Application des paramètres kernel sécurisés..."
cat <<EOF | sudo tee /etc/sysctl.d/99-defendos.conf > /dev/null
net.ipv4.tcp_syncookies = 1
net.ipv4.conf.all.rp_filter = 1
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
kernel.randomize_va_space = 2
kernel.kptr_restrict = 2
kernel.dmesg_restrict = 1
EOF

sudo sysctl --system

# Auditd
echo "Activation d'auditd..."
pacman -S --noconfirm --needed audit
systemctl enable --now auditd

cat <<EOF | sudo tee /etc/audit/rules.d/defendos.rules > /dev/null
-w /etc/passwd -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/sudoers -p wa -k priv
-a always,exit -F arch=b64 -C auid!=unset -F auid>=1000 -F path=/usr/bin/sudo -F key=privileged
EOF

sudo augenrules --load
sudo systemctl restart auditd

systemctl enable --now fail2ban

echo "=== Hardening terminé ! ==="
echo "Vérifie avec : lynis audit system"